package org.soa;




import org.activiti.engine.delegate.*;


public class MyDelegate implements JavaDelegate {

	@Override
	public void execute(DelegateExecution context) throws Exception {
		System.out.println("HELLO");
		String input = (String) context.getVariable("tenantID");
		String input2 = (String) context.getVariable("documentID");
		System.out.println("TenantID is " + input);
		
		// Call Web Service (later)
		//StockQuoteSoapProxy stub = new StockQuoteSoapProxy();
		// String result = stub.getQuote( input );
					
		// set Result
		String result = input + "1234";
		context.setVariable("tenantID", result );
	}

}
