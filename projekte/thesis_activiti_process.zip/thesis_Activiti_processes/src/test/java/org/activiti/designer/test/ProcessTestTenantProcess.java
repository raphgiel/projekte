package org.activiti.designer.test;

import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.FormService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.test.ActivitiRule;
import org.apache.log4j.BasicConfigurator;
import org.junit.Rule;
import org.junit.Test;

import org.apache.log4j.*;
public class ProcessTestTenantProcess {

	public static final Logger LOGGER = Logger.getLogger(ProcessTestTenantProcess.class);
	
	
	
	private String filename = "C:/Users/Raphael/workspace/thesis_Activiti_processes/src/main/resources/diagrams/tenant_process2.bpmn";

	@Rule
	public ActivitiRule activitiRule = new ActivitiRule();

	@Test
	public void startProcess() throws Exception {
	
		
		
		// Logger configuration
		BasicConfigurator.configure();
		
		
		
		RepositoryService repositoryService = activitiRule.getRepositoryService();
		
		repositoryService.createDeployment().addInputStream("tenantProcess2.bpmn20.xml",
				new FileInputStream(filename)).deploy();
		RuntimeService runtimeService = activitiRule.getRuntimeService();
		Map<String, Object> variableMap = new HashMap<String, Object>();
		variableMap.put("name", "Activiti");
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("tenantProcess2", variableMap);
		assertNotNull(processInstance.getId());
		System.out.println("id " + processInstance.getId() + " "
				+ processInstance.getProcessDefinitionId());
		
		
		TaskService taskService = activitiRule.getTaskService(); 
		// processEngine.getTaskService();
		List<Task> tasks = taskService.createTaskQuery().taskAssignee("gonzo").list();

		String processID = processInstance.getProcessInstanceId();
		
		
		
		
		for (Task task : tasks) {
				System.out.println("Following task is available for User gonzo: " + task.getName());
	//			FormService formService = activitiRule.getFormService();
	//			TaskFormData dataForm = formService.getTaskFormData(task.getId());
	/*			List<org.activiti.engine.form.FormProperty> listeProp = dataForm.getFormProperties();
  
				for ( org.activiti.engine.form.FormProperty prop : listeProp ) {
					System.out.println( prop.getName() );
				}
	*/			
				runtimeService.setVariable(processID, "tenantID", "Alfresco");
  
				String varStock = (String) runtimeService.getVariable(processID, "tenantID");
				System.out.println( varStock );
  
				// Task übernehmen (to claim)
				taskService.claim(task.getId(), "gonzo");
  
				System.out.println("GOnzo is there");
				
				// Task abschließen
				System.out.println(task.getId() + task.getName());
				taskService.complete(task.getId());
				System.out.println("OUT OF ORder");
		}

		
		/*	tasks = taskService.createTaskQuery().taskAssignee("gonzo").list();
		for (Task task : tasks) {
			System.out.println("Following task is available for User Gonzo: " + task.getName());
			System.out.println( task.getDescription() );
		}
*/
		System.out.println("Result: " + runtimeService.getVariable(processID, "result")   );

		
		
	}
}