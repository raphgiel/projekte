package org.activiti.designer.test;

import static org.junit.Assert.assertNotNull;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.ProcessEngine;
import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.impl.cfg.StandaloneProcessEngineConfiguration;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.test.ActivitiRule;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class ProcessTestTenantProcess_simple {

	private String filename = "C:/Users/Raphael/workspace/thesis_Activiti_processes/src/main/resources/diagrams/tenant_process.bpmn";
/*
	@Test
	public void startProcess () throws FileNotFoundException {
		ProcessEngine processEngine = ProcessEngineConfiguration
			.createStandaloneInMemProcessEngineConfiguration()
		 	.buildProcessEngine(); 
		 
		RuntimeService runtimeService = processEngine.getRuntimeService(); 
		RepositoryService repositoryService = processEngine.getRepositoryService();
		repositoryService.createDeployment().addInputStream("tenant_process.bpmn20.xml",
				new FileInputStream(filename))
			//.addClasspathResource("bookorder.simple.bpmn20.xml")
			.deploy();
		
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(
				"tenantProcess");
		assertNotNull(processInstance.getId());
		System.out.println("id " + processInstance.getId() + " " 
				+ processInstance.getProcessDefinitionId());
	}
	
	*/
	
	protected ProcessEngine processEngine;
	
	
	@Before
	public void setup() {
		this.processEngine = ProcessEngineConfiguration.createProcessEngineConfigurationFromResource("activiti.cf.xml").buildProcessEngine();
	}
	
	@Test
	public void startProcess() throws Exception {
		RepositoryService repositoryService = processEngine.getRepositoryService();
		repositoryService.createDeployment().addInputStream("tenantProcess.bpmn20.xml",
				new FileInputStream(filename)).deploy();
		RuntimeService runtimeService = processEngine.getRuntimeService();
		Map<String, Object> variableMap = new HashMap<String, Object>();
		variableMap.put("name", "Activiti");
		ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("tenantProcess", variableMap);
		assertNotNull(processInstance.getId());
		System.out.println("id " + processInstance.getId() + " "
				+ processInstance.getProcessDefinitionId());
	}
}